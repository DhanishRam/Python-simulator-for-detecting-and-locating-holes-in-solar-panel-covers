"""Search competing flux- and parallax-constrained aperture hypotheses."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from functools import lru_cache

import numpy as np

from .config import DEPTH, FAMILIES, LENGTH, PER_MODULE, STRIP_AREA
from .optics import EDGES, K_SCALE, diffuse_directions, frame, hits, origin, sunlight

GRID_M = 0.04
MAX_RESIDUAL = 0.50
MIN_FAMILY_MARGIN = 0.025


@dataclass(frozen=True)
class Candidate:
    family: str
    x_m: float
    height_m: float


@dataclass(frozen=True)
class Fit:
    candidate: Candidate
    area_m2: float
    residual: float
    runner_family: str
    runner_residual: float

    @property
    def margin(self):
        return self.runner_residual - self.residual

    def public(self):
        return {**asdict(self.candidate), "area_m2": self.area_m2, "residual": self.residual,
                "runner_family": self.runner_family, "runner_residual": self.runner_residual,
                "family_margin": self.margin}


def box_cdf(edges, center, half):
    """Fraction of a uniform interval to the left of each edge."""
    return np.clip((edges - center[..., None] + half) / (2 * half), 0, 1)


@lru_cache(maxsize=3)
def kernel_bank(scans, gap):
    """Per-unit-area forward library, shape (hypothesis, scan, strip).

    The inverse uses a point-source diffuse fan and a fixed-width beam footprint.
    The observation generator integrates an aperture whose shape depends on its area.
    """
    xs = np.arange(1, round(LENGTH / GRID_M)) * GRID_M
    specs, blocks = [], []
    beams = np.array([sunlight(s) for s in scans])
    dni = np.array([s.dni_w_m2 for s in scans])
    diffuse = np.array([s.diffuse_w_m2 for s in scans])
    poa = np.array([s.poa for s in scans]) * STRIP_AREA
    for family in FAMILIES:
        x_grid = np.array([LENGTH]) if family == "end_flap" else xs
        heights = [gap] if family == "cover" else np.linspace(0.20 * gap, 0.80 * gap, 5)
        n = frame(family)[0]
        weight = np.maximum(beams @ n, 0) * dni
        sky_view = 1.0 if family == "cover" else 0.5
        for z in heights:
            starts = np.array([origin(family, x, z) for x in x_grid])
            directions = diffuse_directions(family, 240)
            scattered = np.array([hits(p, directions) for p in starts])
            t = -z / beams[:, 2]
            x = starts[:, None, 0] + t * beams[:, 0]
            y = starts[:, None, 1] + t * beams[:, 1]
            half = 0.046 if family == "cover" else 0.082
            if family == "end_flap":
                half = (0.004 + 0.032 * np.abs(beams[:, 0] / beams[:, 2]))[:, None]
            along = np.diff(box_cdf(EDGES, x, half), axis=2)
            cross_half = 0.05 if family == "cover" else 0.012
            across = np.diff(box_cdf(np.array([0, DEPTH]), y, cross_half), axis=2)
            direct = along * across * weight[None, :, None]
            sky = scattered[:, None, :] * (sky_view * diffuse)[None, :, None]
            blocks.append(K_SCALE * (direct + sky) / poa[None, :, None])
            specs.extend(Candidate(family, float(v), float(z)) for v in x_grid)
    bank = np.concatenate(blocks)
    bank.setflags(write=False)
    return tuple(specs), bank


def fit_opening(excess, scans, gap, *, whole_module=False):
    """Return the best nonnegative least-squares fit and best competing family."""
    specs, bank = kernel_bank(scans, gap)
    if whole_module:
        bank = bank.reshape(len(bank), len(scans), -1, PER_MODULE).mean(axis=-1)
    if excess.shape != bank.shape[1:]:
        raise ValueError("excess must match the scan count and selected receiver resolution")
    energy = float(np.sum(excess**2))
    if energy <= 1e-24:
        return None
    norm = np.einsum("ijk,ijk->i", bank, bank)
    dot = np.einsum("ijk,jk->i", bank, excess)
    area = np.maximum(0, np.divide(dot, norm, out=np.zeros_like(dot), where=norm > 0))
    residuals = np.clip(1 - area * dot / energy, 0, 1)
    ix = int(np.argmin(residuals))
    other = np.array([s.family != specs[ix].family for s in specs])
    jx = int(np.argmin(np.where(other, residuals, np.inf)))
    return Fit(specs[ix], float(area[ix]), float(residuals[ix]),
               specs[jx].family, float(residuals[jx]))
