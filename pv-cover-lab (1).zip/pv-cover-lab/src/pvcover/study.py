"""Paired noise trials. Every estimator in a trial uses the same day record."""
from collections import Counter

import numpy as np

from .config import MODULES, PER_MODULE, load_scenario
from .day import LOCAL_THRESHOLD, MIN_MARKS, DayRecord, reduce_day
from .inverse import MAX_RESIDUAL, MIN_FAMILY_MARGIN, fit_opening
from .simulation import run

EXPECTED = {
    "intact": "G", "cover-hole": "B", "lower-slot": "F", "upper-slot": "F", "end-flap": "F",
    "partial": "A", "retracted": "A", "wet-liner": "E", "soiling": "D", "module-defect": "C",
    "skirt-lift": "F", "reference-drift": "G", "wiring-fault": "FAULT",
    "unstable-night": "HOLD", "interlock-open": "HOLD",
}
# Ablations compare daylight records with a fully deployed cover and valid night evidence.
DAY_CASES = {"intact", "cover-hole", "lower-slot", "upper-slot", "end-flap", "soiling",
             "module-defect", "skirt-lift", "reference-drift", "wet-liner"}


def ablations(exp):
    r = exp.reduced
    raw = r.corrected / exp.day.baseline - 1
    threshold = np.any((raw > LOCAL_THRESHOLD).sum(axis=0) >= MIN_MARKS)
    persistent = bool(np.any(r.positives >= MIN_MARKS))
    # Coarsen the measurements before normalization and persistence testing.
    # These area-averaged receivers are an optical ablation of spatial resolution.
    day = exp.day
    shape = (len(day.scans), MODULES, PER_MODULE)
    coarse_record = DayRecord(day.scans, day.reference_a, day.current_a.reshape(shape).mean(axis=2),
                              day.retracted_gain.reshape(MODULES, PER_MODULE).mean(axis=1),
                              day.baseline.reshape(shape).mean(axis=2))
    coarse_day = reduce_day(coarse_record)
    module_hole = False
    if np.any(coarse_day.positives >= MIN_MARKS) and not exp.day_issue:
        coarse = fit_opening(coarse_day.excess, day.scans, exp.scenario.gap_m, whole_module=True)
        module_hole = bool(coarse and coarse.candidate.family == "cover"
                           and coarse.residual < MAX_RESIDUAL and coarse.margin >= MIN_FAMILY_MARGIN)
    return bool(threshold), persistent, module_hole


def benchmark(sky, trials, seed):
    if type(trials) is not int or trials < 1:
        raise ValueError("trials must be a positive integer")
    details = []
    for name, expected in EXPECTED.items():
        scenario = load_scenario(name)
        for i in range(trials):
            exp = run(scenario, sky, seed + i)
            ab = ablations(exp) if name in DAY_CASES and not exp.day_issue else (None, None, None)
            fit = exp.fit
            located = (fit is not None and scenario.opening is not None
                       and exp.verdict.label in {"cover_hole", "lower_skirt", "upper_skirt", "end_flap"}
                       and fit.candidate.family == scenario.opening.family)
            details.append({
                "scenario": name, "seed": seed + i, "expected_code": expected,
                "observed_code": exp.verdict.code, "observed_label": exp.verdict.label,
                "raw_threshold_hole": ab[0], "local_threshold_hole": ab[1],
                "module_fit_hole": ab[2], "substring_system_hole": exp.verdict.code == "B",
                "x_error_m": fit.candidate.x_m - scenario.opening.x_m if located else None,
                "area_error_pct": 100*(fit.area_m2 / scenario.opening.area_m2 - 1) if located else None,
            })
    counts = Counter((r["expected_code"], r["observed_code"]) for r in details)
    return details, [{"expected": k[0], "observed": k[1], "count": v} for k, v in sorted(counts.items())]
