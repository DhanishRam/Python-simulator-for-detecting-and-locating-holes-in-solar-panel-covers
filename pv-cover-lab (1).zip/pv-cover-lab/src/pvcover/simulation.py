"""Run one paired day/night experiment. The decision stage receives observations only."""
from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np

from ._version import __version__
from .config import LENGTH, Scenario
from .day import MIN_MARKS, SCAN_S, DayRecord, Reduction, daylight_support, reduce_day, simulate_day
from .inverse import MAX_RESIDUAL, MIN_FAMILY_MARGIN, Fit, fit_opening
from .night import NightResult, night_gate, simulate_night


@dataclass(frozen=True)
class Verdict:
    code: str
    label: str
    reason: str


def incomplete(night):
    return night.index < 0.5 or night.extent_m < LENGTH - 0.14


def decide(night, blocked, day_issue, positive, negative, low_gain, gamma, fit):
    if blocked:
        return Verdict("HOLD", "measurement_blocked", "String isolation is unconfirmed.")
    if night is not None:
        if night.wiring_fault:
            return Verdict("FAULT", "receiver_polarity", "A calibrated optical projection is negative.")
        if incomplete(night):
            return Verdict("A", "incomplete_deployment", "Cavity presence or deployed extent fell below its gate.")
    if night is None or day_issue:
        return Verdict("HOLD", "insufficient_evidence", day_issue or "Night commissioning checks are pending.")
    if positive and fit:
        if fit.residual >= MAX_RESIDUAL:
            return Verdict("F", "unresolved_edge_or_leakage", "Persistent leakage has no adequate single-opening fit.")
        if fit.margin < MIN_FAMILY_MARGIN:
            return Verdict("HOLD", "ambiguous_aperture", "Competing aperture families explain similar energy.")
        if fit.candidate.family == "cover":
            return Verdict("B", "cover_hole", "The cover-plane model explains the moving excess.")
        return Verdict("F", fit.candidate.family, "A wall aperture explains the accepted scans.")
    if positive:
        return Verdict("HOLD", "insufficient_signal", "No aperture area could be estimated.")
    if negative:
        return Verdict("C", "module_defect", "A gain-corrected substring has a persistent deficit.")
    if low_gain:
        return Verdict("D", "soiling_or_degradation", "A retracted substring gain fell below its commissioning band.")
    if night.index < 0.90:
        return Verdict("E", "liner_loss", "Coupling is weak at full extent with no local daylight excess.")
    if not 0.82 <= gamma <= 1.18:
        return Verdict("F", "common_leakage_shift", "The section factor left its band without a local excess.")
    return Verdict("G", "intact", "Extent, liner coupling and substring leakage passed their gates.")


@dataclass
class Experiment:
    scenario: Scenario
    seed: int
    admissions: list
    day: DayRecord
    reduced: Reduction
    night: NightResult | None
    night_issue: str
    day_issue: str
    fit: Fit | None
    verdict: Verdict

    def summary(self):
        n = self.night
        r = self.reduced
        scans = self.day.scans
        return {
            "software_version": __version__, "numpy_version": np.__version__,
            "schema_version": 1, "seed": self.seed, "scenario": self.scenario.name,
            "verdict": asdict(self.verdict),
            "day": {"accepted": len(scans), "attempted": len(self.admissions),
                    "support_gate": self.day_issue or "pass",
                    "theta_span_deg": float(np.ptp([s.theta_deg for s in scans])) if scans else None,
                    "median_gamma": float(np.median(r.gamma)) if scans else None,
                    "persistent_positive_strips": (np.flatnonzero(r.positives >= MIN_MARKS) + 1).tolist(),
                    "persistent_negative_strips": (np.flatnonzero(r.negatives >= MIN_MARKS) + 1).tolist(),
                    "low_gain_strips": (np.flatnonzero(self.day.retracted_gain < 0.82) + 1).tolist()
                    if self.scenario.isolated else [],
                    "best_fit": self.fit.public() if self.fit else None},
            "night": {"gate": self.night_issue or "pass", "coupling_index": n.index if n else None,
                      "extent_m": n.extent_m if n else None, "reflectance_scale": n.liner_scale if n else None,
                      "polarity_fault": n.wiring_fault if n else None},
        }


def run(scenario, sky, seed=42):
    """Simulate independent random streams for a night session and a later daylight sequence."""
    if type(seed) is not int or seed < 0:
        raise ValueError("seed must be a nonnegative integer")
    sky = tuple(sky)
    if not sky or any(b.time_s <= a.time_s for a, b in zip(sky, sky[1:])):
        raise ValueError("sky scans must be nonempty and have increasing timestamps")
    day_rng, night_rng = [np.random.default_rng(s) for s in np.random.SeedSequence(seed).spawn(2)]
    blocked = not scenario.isolated
    admissions = []
    ready_at = 0.0
    for scan in sky:
        reason = "isolation_unconfirmed" if blocked else scan.rejection()
        if not reason and scan.time_s + 1e-9 < ready_at:
            reason = "acquisition_busy"
        if not reason:
            ready_at = scan.time_s + SCAN_S
        admissions.append((scan, reason))
    accepted = tuple(s for s, why in admissions if not why)
    night_issue = "isolation_unconfirmed" if blocked else night_gate(scenario)
    night = None if night_issue else simulate_night(scenario, night_rng)
    day = simulate_day(scenario, accepted, day_rng)
    reduced = reduce_day(day)
    day_issue = "isolation_unconfirmed" if blocked else daylight_support(accepted)
    positive = bool(np.any(reduced.positives >= MIN_MARKS))
    negative = bool(np.any(reduced.negatives >= MIN_MARKS))
    fit = None
    if positive and not day_issue and night and not (night.wiring_fault or incomplete(night)):
        fit = fit_opening(reduced.excess, accepted, scenario.gap_m)
    gamma = float(np.median(reduced.gamma)) if accepted else 1.0
    verdict = decide(night, blocked, day_issue, positive, negative, np.any(day.retracted_gain < 0.82), gamma, fit)
    return Experiment(scenario, seed, admissions, day, reduced, night, night_issue, day_issue, fit, verdict)
