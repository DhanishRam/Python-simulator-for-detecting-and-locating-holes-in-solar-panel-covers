"""Generate daytime current measurements and reduce them against commissioning records."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .config import LENGTH, N_STRIPS, PER_MODULE, PITCH
from .optics import aperture_signal, sunlight

ISC_A = 12.0
REFERENCE_STC_A = 0.050
LOCAL_THRESHOLD = 0.10
SETTLE_S = 0.8
INTEGRATE_S = 1.6
SCAN_S = N_STRIPS * (SETTLE_S + INTEGRATE_S)
MIN_MARKS = 3
MIN_SPAN_DEG = 15.0


def baseline(scans, gap):
    """Smooth synthetic commissioning surface with naturally leaky end strips."""
    x = (np.arange(N_STRIPS) + 0.5) * PITCH
    edge_l = np.exp(-x / 0.52)
    edge_r = np.exp(-(LENGTH - x) / 0.52)
    rows = []
    for sky in scans:
        diffuse = sky.diffuse_w_m2 / sky.poa
        along = sunlight(sky)[0]
        edges = (1 - 0.35 * along) * edge_l + (1 + 0.35 * along) * edge_r
        rows.append((0.0030 + 0.009 * edges) * (1 + 0.45 * diffuse) * (0.32 / gap)**0.35)
    return np.array(rows).reshape(-1, N_STRIPS)


@dataclass
class DayRecord:
    scans: tuple
    reference_a: np.ndarray
    current_a: np.ndarray
    retracted_gain: np.ndarray
    baseline: np.ndarray


@dataclass
class Reduction:
    corrected: np.ndarray
    gamma: np.ndarray
    relative: np.ndarray
    excess: np.ndarray
    positives: np.ndarray
    negatives: np.ndarray


def simulate_day(scenario, scans, rng):
    """Return electrical observations and synthetic records available to an estimator."""
    base = baseline(scans, scenario.gap_m)
    gain = np.ones(N_STRIPS)
    if scenario.soiled_strip is not None:
        gain[scenario.soiled_strip - 1] = 0.72
    # Retraction is a distinct acquisition with independent calibration error.
    gain_record = gain * rng.normal(1, scenario.relative_noise * 0.35, N_STRIPS)
    baseline_record = base * rng.normal(1, scenario.relative_noise * 0.25, N_STRIPS)
    leakage = base * scenario.uniform_leak_factor
    if scenario.opening is not None and scans:
        leakage += aperture_signal(scenario.opening, scenario.gap_m, scans)
    if scenario.defect_strip is not None:
        leakage[:, scenario.defect_strip - 1] *= 0.65
    # Newly exposed portions see direct daylight during a failed deployment.
    left_edges = np.arange(N_STRIPS) * PITCH
    covered = np.clip((scenario.deployed_fraction * LENGTH - left_edges) / PITCH, 0, 1)
    leakage = leakage * covered + PER_MODULE * (1 - covered)
    irradiance = np.array([s.poa for s in scans])[:, None] / 1000
    current = leakage * gain * ISC_A / PER_MODULE * irradiance
    current *= np.maximum(0, rng.normal(1, scenario.relative_noise, current.shape))
    reference = irradiance[:, 0] * REFERENCE_STC_A * scenario.reference_scale
    return DayRecord(scans, reference, current, gain_record, baseline_record)


def reduce_day(record):
    """Use only measured currents and commissioning values; retain signed excess."""
    index = (record.current_a / record.reference_a[:, None]) * (REFERENCE_STC_A / ISC_A) * PER_MODULE
    corrected = index / record.retracted_gain
    gamma = np.median(corrected / record.baseline, axis=1)
    common = gamma[:, None] * record.baseline
    excess = corrected - common
    relative = excess / common
    return Reduction(corrected, gamma, relative, excess,
                     (relative > LOCAL_THRESHOLD).sum(axis=0),
                     (relative < -LOCAL_THRESHOLD).sum(axis=0))


def daylight_support(scans):
    if len(scans) < MIN_MARKS:
        return "too_few_scans"
    angles = [s.theta_deg for s in scans]
    if max(angles) - min(angles) < MIN_SPAN_DEG:
        return "narrow_angle_span"
    direct_angles = [s.theta_deg for s in scans if s.dni_w_m2 / s.poa >= 0.25]
    if len(direct_angles) < MIN_MARKS:
        return "weak_direct_light"
    if max(direct_angles) - min(direct_angles) < MIN_SPAN_DEG:
        return "narrow_direct_angle_span"
    return ""
