"""Public experiment inputs. All distances are metres and all angles are degrees."""
from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass, fields
from importlib.resources import files
from pathlib import Path

DATA = files("pvcover").joinpath("data")
FAMILIES = ("cover", "lower_skirt", "upper_skirt", "end_flap")
MODULES = 4
PER_MODULE = 3
N_STRIPS = MODULES * PER_MODULE
PITCH = 0.40
LENGTH = N_STRIPS * PITCH
DEPTH = 2.0
STRIP_AREA = DEPTH * PITCH


def number(name, value, low, high):
    if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{name} must be a finite number in [{low}, {high}]")


@dataclass(frozen=True)
class Opening:
    family: str
    x_m: float
    area_m2: float
    height_m: float | None = None

    def validate(self, gap):
        if self.family not in FAMILIES:
            raise ValueError(f"opening.family must be one of {FAMILIES}")
        number("opening.x_m", self.x_m, 0, LENGTH)
        number("opening.area_m2", self.area_m2, 0.00001, 0.025)
        if self.family == "cover":
            if self.height_m is not None:
                raise ValueError("cover height is set by gap_m")
            half_width = math.sqrt(self.area_m2 / math.pi)
        else:
            number("opening.height_m", self.height_m, 0, gap)
            # The synthetic rectangular slot has a 3:1 horizontal aspect ratio.
            half_height = math.sqrt(self.area_m2 / 3) / 2
            if not half_height <= self.height_m <= gap - half_height:
                raise ValueError("slot extends beyond the skirt height")
            half_width = 3 * half_height
        if self.family == "end_flap":
            if not math.isclose(self.x_m, LENGTH, abs_tol=1e-10):
                raise ValueError("the end flap is at the far end of the row")
        elif not half_width <= self.x_m <= LENGTH - half_width:
            raise ValueError("opening extends beyond its plane")


@dataclass(frozen=True)
class Scenario:
    name: str = "intact"
    gap_m: float = 0.32
    opening: Opening | None = None
    deployed_fraction: float = 1.0
    liner_factor: float = 1.0
    uniform_leak_factor: float = 1.0
    reference_scale: float = 1.0
    soiled_strip: int | None = None
    defect_strip: int | None = None
    reversed_receiver: int | None = None
    relative_noise: float = 0.012
    cell_temp_c: float = 29.0
    isolated: bool = True
    night_irradiance_w_m2: float = 0.1
    hours_after_sunset: float = 2.0
    voltage_change_fraction: float = 0.0002

    def __post_init__(self):
        if not isinstance(self.name, str) or not self.name.strip() or len(self.name) > 100:
            raise ValueError("name must contain 1 to 100 characters")
        for key, lo, hi in (
            ("gap_m", 0.2, 0.4), ("deployed_fraction", 0, 1), ("liner_factor", 0.2, 1.15),
            ("uniform_leak_factor", 0.5, 3), ("reference_scale", 0.5, 2),
            ("relative_noise", 0, 0.15), ("cell_temp_c", -20, 70),
            ("night_irradiance_w_m2", 0, 1500), ("hours_after_sunset", 0, 24),
            ("voltage_change_fraction", 0, 1),
        ):
            number(key, getattr(self, key), lo, hi)
        for key, hi in (("soiled_strip", N_STRIPS), ("defect_strip", N_STRIPS),
                        ("reversed_receiver", MODULES)):
            v = getattr(self, key)
            if v is not None and (type(v) is not int or not 1 <= v <= hi):
                raise ValueError(f"{key} must be a 1-based integer from 1 to {hi}")
        if type(self.isolated) is not bool:
            raise ValueError("isolated must be true or false")
        if self.opening is not None:
            if not isinstance(self.opening, Opening):
                raise ValueError("opening must be an object")
            self.opening.validate(self.gap_m)


def scenario_from_dict(data):
    if not isinstance(data, dict):
        raise ValueError("scenario must be a JSON object")
    data = data.copy()
    try:
        if data.get("opening") is not None:
            data["opening"] = Opening(**data["opening"])
        return Scenario(**data)
    except TypeError as exc:
        raise ValueError(f"invalid scenario fields: {exc}") from exc


def presets():
    return json.loads(DATA.joinpath("presets.json").read_text(encoding="utf-8"))


def load_scenario(name="cover-hole", path=None):
    if path is not None:
        return scenario_from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
    catalog = presets()
    if name not in catalog:
        raise ValueError(f"unknown preset {name!r}; use 'pvcover list'")
    return scenario_from_dict({"name": name, **catalog[name]})


@dataclass(frozen=True)
class Sky:
    time_s: float
    theta_deg: float
    phi_deg: float
    dni_w_m2: float
    diffuse_w_m2: float
    wind_m_s: float
    settled_s: float
    ref_change: float

    def __post_init__(self):
        for key, lo, hi in (("time_s", 0, 1e9), ("theta_deg", 0, 89.9),
                            ("phi_deg", -180, 180), ("dni_w_m2", 0, 1600),
                            ("diffuse_w_m2", 0, 1600), ("wind_m_s", 0, 100),
                            ("settled_s", 0, 1e9), ("ref_change", 0, 10)):
            number(key, getattr(self, key), lo, hi)

    @property
    def poa(self):
        return self.dni_w_m2 * math.cos(math.radians(self.theta_deg)) + self.diffuse_w_m2

    def rejection(self):
        if self.settled_s < 30:
            return "unsettled"
        if self.wind_m_s >= 5:
            return "wind"
        if self.theta_deg > 65:
            return "incidence"
        if self.poa < 50:
            return "dim"
        if self.ref_change > 0.02:
            return "reference_unstable"
        return ""


def load_sky(path=None):
    resource = DATA.joinpath("sky.csv") if path is None else Path(path)
    with resource.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        names = [f.name for f in fields(Sky)]
        if reader.fieldnames is None or sorted(reader.fieldnames) != sorted(names):
            raise ValueError("sky CSV requires exactly these columns: " + ", ".join(names))
        rows = []
        for line, row in enumerate(reader, 2):
            try:
                rows.append(Sky(**{k: float(v) for k, v in row.items()}))
            except (ValueError, TypeError) as exc:
                raise ValueError(f"sky CSV line {line}: {exc}") from exc
    if not rows or any(b.time_s <= a.time_s for a, b in zip(rows, rows[1:])):
        raise ValueError("sky must contain at least one row in strictly increasing time order")
    return tuple(rows)
