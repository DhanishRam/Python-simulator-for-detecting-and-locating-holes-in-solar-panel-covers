"""Aperture illumination on a finite, strip-segmented rectangular receiver."""
from __future__ import annotations

from functools import lru_cache

import numpy as np

from .config import DEPTH, LENGTH, N_STRIPS, PITCH, STRIP_AREA, Opening, Sky

# Synthetic response scale for all orientations. Commissioned against unit area.
K_SCALE = 0.90
EDGES = np.arange(N_STRIPS + 1) * PITCH


def frame(family):
    """Return the inward normal and two orthogonal in-plane axes."""
    axes = np.eye(3)
    x, y, z = axes
    return {
        "cover": (-z, x, y), "lower_skirt": (y, x, z),
        "upper_skirt": (-y, x, z), "end_flap": (-x, y, z),
    }[family]


def origin(family, x, z):
    y = {"lower_skirt": 0.0, "upper_skirt": DEPTH}.get(family, DEPTH / 2)
    return np.array([x, y, z])


def sunlight(sky: Sky):
    theta, phi = np.radians([sky.theta_deg, sky.phi_deg])
    return np.array([np.sin(theta) * np.cos(phi), np.sin(theta) * np.sin(phi), -np.cos(theta)])


@lru_cache(maxsize=16)
def diffuse_directions(family, count):
    """Equal-weight cosine-hemisphere quadrature, including escaping rays."""
    n, u, v = frame(family)
    i = np.arange(count) + 0.5
    r = np.sqrt(i / count)
    angle = 2 * np.pi * i * ((5**0.5 - 1) / 2)
    return (np.outer(np.sqrt(1 - r*r), n) + np.outer(r * np.cos(angle), u)
            + np.outer(r * np.sin(angle), v))


def hits(starts, directions):
    """Fraction of all launched rays reaching each strip on the first pass."""
    dz = directions[..., 2]
    downward = dz < -1e-10
    t = np.divide(-starts[..., 2], dz, out=np.zeros(np.broadcast_shapes(starts[..., 2].shape, dz.shape)),
                  where=downward)
    landed = starts[..., :2] + t[..., None] * directions[..., :2]
    x, y = landed.T
    valid = downward & (x >= 0) & (x < LENGTH) & (y >= 0) & (y < DEPTH)
    counts = np.bincount(np.minimum((x[valid] / PITCH).astype(int), N_STRIPS - 1),
                         minlength=N_STRIPS)
    return counts / len(x)


def aperture_points(opening, gap, count):
    """Sample a finite disk or rectangular slot, independently of inverse kernels."""
    i = np.arange(count) + 0.5
    # Coprime permutations decouple surface position from angular quadrature.
    a = ((i * 421) % count) / count
    b = ((i * 673) % count) / count
    _, u, v = frame(opening.family)
    if opening.family == "cover":
        r = np.sqrt(a * opening.area_m2 / np.pi)
        da, db = r * np.cos(2 * np.pi * b), r * np.sin(2 * np.pi * b)
        z = gap
    else:
        side = np.sqrt(opening.area_m2 / 3)
        da, db = 3 * side * (a - 0.5), side * (b - 0.5)
        z = opening.height_m
    return origin(opening.family, opening.x_m, z) + np.outer(da, u) + np.outer(db, v)


def aperture_signal(opening: Opening, gap: float, scans):
    count = 2048
    points = aperture_points(opening, gap, count)
    normal = frame(opening.family)[0]
    diffuse = hits(points, diffuse_directions(opening.family, count))
    sky_view = 1.0 if opening.family == "cover" else 0.5
    values = []
    for scan in scans:
        beam = sunlight(scan)
        direct = scan.dni_w_m2 * max(float(beam @ normal), 0) * hits(points, beam)
        scattered = scan.diffuse_w_m2 * sky_view * diffuse
        values.append(opening.area_m2 * K_SCALE * (direct + scattered) / (STRIP_AREA * scan.poa))
    return np.asarray(values)
