"""Discrete acquisition schedule. All modes are logical states on a simulated clock."""
from dataclasses import dataclass

from .config import MODULES, N_STRIPS, PER_MODULE
from .day import INTEGRATE_S, SCAN_S, SETTLE_S
from .simulation import incomplete


@dataclass(frozen=True)
class Event:
    session: str
    time_s: float
    action: str
    module: int | str = ""
    strip: int | str = ""
    module_modes: str = "string|string|string|string"


def timeline(exp):
    """Night and day use separate clocks. Day time zero is the first scheduled scan."""
    yield Event("night", 0, "verification_requested")
    if exp.night is None:
        yield Event("night", 0, exp.night_issue)
        yield Event("night", 90, "deployment_unverified_alarm")
    else:
        yield Event("night", 0, "isolation_confirmed")
        for j in range(MODULES):
            modes = "|".join("emit" if j == k else "whole_receive" for k in range(MODULES))
            yield Event("night", j * 16, "ramp_up", j + 1, module_modes=modes)
            yield Event("night", j * 16 + 2, "integrate_10s", j + 1, module_modes=modes)
            yield Event("night", j * 16 + 12, "ramp_down", j + 1, module_modes=modes)
            yield Event("night", j * 16 + 14, "idle")
        yield Event("night", 64, "restore_string")
        if exp.night.wiring_fault or incomplete(exp.night):
            yield Event("night", 90, "deployment_unverified_alarm")
        else:
            yield Event("night", 64, "deployment_verified")
    for scan, why in exp.admissions:
        start = scan.time_s
        if why:
            yield Event("day", start, why)
            continue
        yield Event("day", start, "isolation_confirmed")
        # Sequential selection with 0.8 s settling and 1.6 s integration.
        slot_s = SETTLE_S + INTEGRATE_S
        for s in range(N_STRIPS):
            j = s // PER_MODULE
            modes = "|".join("strip_receive" if j == k else "string" for k in range(MODULES))
            yield Event("day", round(start + s * slot_s, 3), "select_strip", j+1, s+1, modes)
            yield Event("day", round(start + s * slot_s + SETTLE_S, 3), "integrate_1.6s", j+1, s+1, modes)
        yield Event("day", round(start + SCAN_S, 3), "restore_string")
