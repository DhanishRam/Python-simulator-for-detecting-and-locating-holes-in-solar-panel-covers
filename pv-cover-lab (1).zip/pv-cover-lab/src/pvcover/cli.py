"""The pvcover command-line interface."""
import argparse
from csv import Error as CSVError
from dataclasses import asdict, fields
import sys

from . import __version__
from .config import Sky, load_scenario, load_sky, presets
from .output import new_bundle, write_experiment, write_json, write_rows
from .simulation import run
from .study import benchmark


def main(argv=None):
    parser = argparse.ArgumentParser(prog="pvcover", description="Simulate optical verification of a PV cover.")
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("list", help="list built-in synthetic scenarios")
    one = sub.add_parser("run", help="run one paired night/day experiment")
    sources = one.add_mutually_exclusive_group()
    sources.add_argument("--preset", default="cover-hole", help="built-in scenario (default: cover-hole)")
    sources.add_argument("--scenario", help="custom JSON scenario file")
    study = sub.add_parser("benchmark", help="compare faults and ablations across repeated noise draws")
    study.add_argument("--trials", type=int, default=5)
    for command in [one, study]:
        command.add_argument("--sky", help="custom CSV scan schedule")
        command.add_argument("--seed", type=int, default=42)
        command.add_argument("--out", required=True, help="new output directory")
    args = parser.parse_args(argv)
    try:
        if args.command == "list":
            print("\n".join(presets()))
            return 0
        sky = load_sky(args.sky)
        with new_bundle(args.out) as out:
            if args.command == "run":
                exp = run(load_scenario(args.preset, args.scenario), sky, args.seed)
                write_experiment(exp, out)
                message = f"{exp.verdict.code}  {exp.verdict.label}  |  {exp.verdict.reason}"
            else:
                rows, confusion = benchmark(sky, args.trials, args.seed)
                write_rows(out / "trials.csv", list(rows[0]), rows)
                write_json(out / "confusion.json", confusion)
                write_json(out / "settings.json", {"version": __version__, "start_seed": args.seed,
                                                   "trials_per_scenario": args.trials})
                write_rows(out / "sky.csv", [f.name for f in fields(Sky)], (asdict(s) for s in sky))
                hits = sum(r["expected_code"] == r["observed_code"] for r in rows)
                message = f"{hits}/{len(rows)} synthetic trials matched the expected verdict code."
        print(message)
        print(f"Results in {args.out}")
        return 0
    except (OSError, ValueError, CSVError) as exc:
        print(f"pvcover: {exc}", file=sys.stderr)
        return 2

