"""Portable, atomic run bundles with SI units in column names."""
from __future__ import annotations

import csv
import json
from contextlib import contextmanager
from dataclasses import asdict, fields
from pathlib import Path
from tempfile import TemporaryDirectory

from .acquisition import Event, timeline
from .config import N_STRIPS, Sky
from .night import PairRecord


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_rows(path, names, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, names)
        writer.writeheader()
        writer.writerows(rows)


@contextmanager
def new_bundle(path):
    """Publish complete output in a new directory; never merge with older traces."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise FileExistsError(f"output already exists: {target}")
    with TemporaryDirectory(dir=target.parent) as tmp:
        staging = Path(tmp) / "bundle"
        staging.mkdir()
        yield staging
        staging.rename(target)


def write_experiment(exp, out):
    write_json(out / "summary.json", exp.summary())
    write_json(out / "scenario.json", asdict(exp.scenario))
    sky_names = [f.name for f in fields(Sky)]
    write_rows(out / "sky.csv", sky_names, (asdict(s) for s, _ in exp.admissions))
    write_rows(out / "scan_log.csv", ["time_s", "admission"],
               ({"time_s": s.time_s, "admission": why or "accepted"} for s, why in exp.admissions))
    write_rows(out / "timeline.csv", [f.name for f in fields(Event)], (asdict(e) for e in timeline(exp)))
    names = ["time_s", "strip", "reference_a", "current_a", "gain", "baseline", "corrected",
             "gamma", "relative_excess", "absolute_excess"]
    r, d = exp.reduced, exp.day
    rows = (dict(zip(names, (sky.time_s, j+1, d.reference_a[i], d.current_a[i, j], d.retracted_gain[j],
                             d.baseline[i, j], r.corrected[i, j], r.gamma[i], r.relative[i, j],
                             r.excess[i, j])))
            for i, sky in enumerate(d.scans) for j in range(N_STRIPS))
    write_rows(out / "day.csv", names, rows)
    write_rows(out / "night.csv", [f.name for f in fields(PairRecord)],
               (asdict(p) for p in exp.night.pairs) if exp.night else ())
