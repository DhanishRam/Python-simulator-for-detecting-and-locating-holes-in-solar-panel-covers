"""Single source of the package version, also recorded in experiment metadata."""
__version__ = "0.1.0"
