"""Reciprocal cavity measurements with calibrated, signed complex demodulation."""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

import numpy as np

from .config import LENGTH, MODULES

FREQUENCY_HZ = 37
SAMPLE_HZ = 888
DURATION_S = 10
BETA_PER_C = -0.006
GAMMA_V_PER_C = -0.002
N_SERIES = 60
COMMISSION_C = 25.0
VF0 = 38.0
INJECTION_A = 2.0
EL_EFFICIENCY = 0.0008
PAIR_LIST = tuple((j, k) for j in range(MODULES) for k in range(MODULES) if j != k)


@lru_cache(maxsize=1)
def oscillator():
    phase = 2 * np.pi * FREQUENCY_HZ * np.arange(SAMPLE_HZ * DURATION_S) / SAMPLE_HZ
    return np.exp(1j * phase)


def demodulate(samples):
    """Peak complex fundamental of an integer-cycle record, negative sine for Q."""
    carrier = oscillator()
    if np.shape(samples) != carrier.shape:
        raise ValueError(f"lock-in requires {len(carrier)} samples")
    return 2 * np.mean(samples * carrier.conj())


def projection(z, retracted, phase):
    return float(((z - retracted) * np.exp(-1j * phase)).real)


@lru_cache(maxsize=1)
def extent_curves():
    """Integrate positive local sensitivities to get a monotone commissioning library."""
    edges = np.linspace(0, LENGTH, 241)
    mid = (edges[:-1] + edges[1:]) / 2
    # Leading-end contrast modulates local sensitivity in this reduced model.
    contrast = np.where(mid > LENGTH - 1.2, 0.76 + 0.22*np.cos(mid * 19)**2, 1)
    curves = []
    for j, k in PAIR_LIST:
        center = (j + k + 1) * LENGTH / (2 * MODULES)
        weight = (0.035 + np.exp(-0.5*((mid - center) / 0.62)**2)) * contrast
        integral = np.r_[0, np.cumsum(weight)]
        curves.append(integral / integral[-1])
    return edges, np.array(curves)


@dataclass
class PairRecord:
    emitter: int
    receiver: int
    i_a: float
    q_a: float
    retracted_i_a: float
    retracted_q_a: float
    phase_rad: float
    calibration_a: float
    forward_v: float
    signed_ratio: float


@dataclass
class NightResult:
    index: float
    extent_m: float
    liner_scale: float
    wiring_fault: bool
    pairs: list[PairRecord]


def night_gate(scenario):
    if scenario.night_irradiance_w_m2 >= 1:
        return "night_too_bright"
    if scenario.hours_after_sunset < 1:
        return "too_early"
    if scenario.voltage_change_fraction > 0.001:
        return "forward_voltage_unstable"
    return ""


def simulate_night(scenario, rng):
    edges, curves = extent_curves()
    extent = scenario.deployed_fraction * LENGTH
    carrier = oscillator()
    temp_delta = scenario.cell_temp_c - COMMISSION_C
    forward_v = VF0 + N_SERIES * GAMMA_V_PER_C * temp_delta
    inferred_delta = (forward_v - VF0) / (N_SERIES * GAMMA_V_PER_C)
    gap_scale = np.exp(1.15 * (scenario.gap_m - 0.32))
    pairs = []
    for i, (j, k) in enumerate(PAIR_LIST):
        # Both commissioning and observations use the measured section gap.
        coupling = 0.034 * gap_scale * 0.41**(abs(j - k) - 1)
        phase = -0.18 + 0.03*j - 0.02*k
        strength = INJECTION_A * EL_EFFICIENCY * coupling
        zr = strength * (0.12 + 0.38j)
        intact = zr + strength * np.exp(1j * phase)
        psi = np.angle(intact - zr)
        s0 = projection(intact, zr, psi)
        cover = np.interp(extent, edges, curves[i])
        attenuation = 1.0
        if scenario.opening is not None:
            midpoint = (j + k + 1) * LENGTH / (2 * MODULES)
            attenuation -= 2 * scenario.opening.area_m2 * np.exp(-abs(midpoint - scenario.opening.x_m))
        signal = cover * attenuation * scenario.liner_factor * strength * (1 + BETA_PER_C * temp_delta)
        # A reversed receiver flips the optical path. An independent electrical
        # feedthrough term remains in the reference channel in this fault model.
        sign = -1 if k + 1 == scenario.reversed_receiver else 1
        drift = 0.045j * strength * np.exp(1j * psi)
        phasor = zr + drift + sign * signal * np.exp(1j * phase)
        waveform = 3*strength + (phasor * carrier).real
        waveform += rng.normal(0, strength * scenario.relative_noise * 12, len(carrier))
        measured = demodulate(waveform)
        ratio = projection(measured, zr, psi) / (s0 * (1 + BETA_PER_C * inferred_delta))
        pairs.append(PairRecord(j + 1, k + 1, float(measured.real), float(measured.imag),
                                float(zr.real), float(zr.imag), float(psi), s0, forward_v, ratio))
    return interpret_pairs(pairs)


def interpret_pairs(pairs):
    """Estimate a common reflectance scale and extent using adjacent reciprocal pairs."""
    edges, curves = extent_curves()
    adj = np.array([abs(j-k) == 1 for j, k in PAIR_LIST])
    ratios = np.array([p.signed_ratio for p in pairs])
    y = ratios[adj]
    design = curves[adj]
    norm = np.sum(design**2, axis=0)
    scale = np.clip(np.divide(y @ design, norm, out=np.zeros_like(norm), where=norm > 0), 0, 1.2)
    error = np.sum((y[:, None] - design * scale)**2, axis=0)
    ix = int(np.argmin(error))
    # Close to the dark floor extent is optically unobservable.
    extent = 0.0 if np.max(np.abs(y)) < 0.02 else float(edges[ix])
    return NightResult(float(y.mean()), extent, float(scale[ix]), bool(np.any(ratios < -0.08)), pairs)
