# Contributing to PV Cover Lab

Install an editable checkout and run the test suite before changing the model.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev,plot]"
python -m unittest discover -s tests -v
```

## Working on the model

Keep synthetic truth inside the measurement generator and scoring code. A decision function should receive observations and commissioning data that an instrument could obtain. New physics should state its units, coordinate convention, operating range and dominant approximation. Put a test beside a quantity with a calculable limit, such as captured power at normal incidence or the sign of a reversed lock-in channel.

For a new preset, add a synthetic case to `src/pvcover/data/presets.json`, its expected code to `study.py` and an appropriate assertion in the experiment tests. Use an off-grid aperture location where possible. Include a competing fault or missing-evidence case when expanding the classifier.

## Checking a change

```bash
python -m coverage run -m unittest discover -s tests
python -m coverage report
pvcover benchmark --trials 10 --seed 42 --out runs/check
python -m build
```

Coverage includes branches. CI uses an 85% reporting threshold. Rebuild the figure and update the example summary or results table if a model change alters the public examples. Retain both false declarations and held verdicts when reporting performance.

For a pull request, describe the physical or software change, the command used to test it and the observed effect. Use synthetic or explicitly redistributable data. Keep site coordinates, asset identifiers, institutional documents and raw field records out of public fixtures.
