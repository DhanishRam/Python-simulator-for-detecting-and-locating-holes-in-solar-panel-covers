# Model and decision rules

## Geometry and inputs

The receiver plane is a synthetic 4.80 m × 2.00 m rectangle. Four modules each contain three strips at 0.40 m pitch. The x axis runs along the row from the roller, y runs across the row and z points from the glass toward the cover. Strip and module IDs in the exported data start at 1. A cover hole is centred at mid-width. Both long skirts and the far end flap have inward-facing normals. The measured gap selects the kernels, night calibration and daylight baseline for that section.

Use the bundled sky as the header template. Times are seconds from the start of the daylight record and must increase. The incident beam travels toward the glass with direction $(\sin\theta\cos\phi,\sin\theta\sin\phi,-\cos\theta)$. The angles in the CSV are degrees in the module frame. DNI is beam irradiance normal to the beam. The diffuse column is diffuse irradiance on the cover plane. The model computes total plane-of-array irradiance as $G = G_b\cos\theta + G_d$. The synthetic scan angles are supplied directly to the solver. [Example sky](../src/pvcover/data/sky.csv)

| Scenario field | Meaning |
| --- | --- |
| `gap_m` | Measured height, 0.20–0.40 m |
| `opening` | Optional object with `family`, `x_m`, `area_m2` and wall-only `height_m`. Families are `cover`, `lower_skirt`, `upper_skirt`, `end_flap`. The end flap is at x = 4.80 m. |
| `deployed_fraction`, `liner_factor` | Fraction of row covered, and relative optical return of the liner |
| `uniform_leak_factor`, `reference_scale` | Multipliers applied to background leakage and to the uncovered reference channel |
| `soiled_strip`, `defect_strip` | A low retracted gain or a local deficit arising after the gain record. Indices are 1–12. |
| `reversed_receiver` | Receiver module 1–4 with reversed optical polarity |
| `relative_noise`, `cell_temp_c` | Relative day readout standard deviation, and night emitter temperature in °C |
| `isolated` | Logical confirmation that the section is isolated for measurement |
| `night_irradiance_w_m2`, `hours_after_sunset`, `voltage_change_fraction` | Night cycle eligibility |

The public API accepts the same fields as the JSON loader. Opening area lies between 0.00001 and 0.025 m² for the generated fixtures. The finite aperture must fit on its physical plane. [Defaults and validation](../src/pvcover/config.py)

## Daylight observation

The synthetic intact baseline is higher near row ends. It varies with beam direction, diffuse fraction and gap. A finite cover hole is a disk. A skirt slot is a rectangle with horizontal-to-vertical aspect ratio 3. The transport solver uses 2,048 equal-weight surface samples and cosine-weighted diffuse directions. First-pass rays that miss the finite glass area escape. For a unit-area aperture, the receiver kernel is

$$
K_s = \frac{c_K}{A_s G}\left[G_b\max(0,\hat s\cdot\hat n) b_s + G_d v_f d_s\right].
$$

Here $b_s$ and $d_s$ are the captured fractions of direct and diffuse rays. The sky-view factor $v_f$ is 1 for the roof and 0.5 for a wall. The synthetic optical scale $c_K$ is 0.90. The contribution is $A K_s$ for an opening of area $A$. Direct rays move a distance $z\tan\theta\cos\phi$ along the row. Their projected flux also changes with the plane normal. Both effects help identify the aperture family.

Each scan produces twelve strip currents and a simultaneous reference current. Within one scan the sky is held constant. A forward model applies the illumination-dependent baseline, opening, gains and measurement noise. Reference drift acts on the reference current. Partly uncovered strips receive an area-weighted mixture of cavity light and open illumination. Independent synthetic commissioning observations supply strip gains and intact baselines.

## Daylight inference

From current $I_s$, reference $I_r$, STC currents and the retracted gain $g_s$, compute

$$
D_s=3\frac{I_s}{I_r}\frac{I_{r,\mathrm{STC}}}{I_{\mathrm{SC}}g_s},\quad
\Gamma=\operatorname{median}_s(D_s/B_s),\quad
e_s=D_s-\Gamma B_s.
$$

The fractional excess is $e_s/(\Gamma B_s)$. At least three accepted scans must mark the **same** strip above +10% to start a positive fit. The scans need not be consecutive. Negative marks below −10% are tracked separately. An unusually low gain can remain observable after gain correction has removed a daylight deficit.

The inverse library searches a 4 cm x grid. It uses the measured roof height and five wall heights spanning 20–80% of that gap. The end flap has fixed x. Diffuse light uses a 240-ray point-source fan. Direct light uses a finite-width interval integrated across strip boundaries. All candidate families compete on the same signed data.

$$
\hat A = \max\left(0,\frac{\sum_{t,s}e_s(t)K_s(t)}{\sum_{t,s} K_s(t)^2}\right),\qquad
\rho = \frac{\sum_{t,s}(e_s(t)-\hat A K_s(t))^2}{\sum_{t,s} e_s(t)^2}.
$$

The reported residual is a **squared-energy fraction**. An accepted match requires $\rho<0.50$ and a gap of at least 0.025 to the best competing family. The margin measures separation between fits. Its conversion to a probability would require calibration. A single physical strip can leave several nearby x values almost indistinguishable. Position uncertainty depends on the observed angular motion and the width of the strip response.

## Night measurement

An intact coupling envelope falls with pair separation and depends on the section gap. Fractional extent is mapped to pair coupling by integrating a positive local sensitivity over the covered part of the row. A spatial modulation near the leading end represents liner contrast. This approximation gives a monotone commissioning curve for each pair. The emitter’s effective optical fundamental is proportional to injection current, emission efficiency and pair coupling.

Each of the twelve directed links produces 8,880 samples over ten seconds at 37 Hz. The generator includes DC, a phase-shifted optical fundamental, electrical pickup, quadrature drift and additive noise. Synthetic retraction and intact records fix the complex pickup $Z_r$, reference phase $\psi$ and positive commissioning amplitude $S_0$.

$$
Z=\frac{2}{n}\sum_{k=0}^{n-1}i_k e^{-2\pi\mathrm{i} f k/f_s},\qquad
R=\frac{\operatorname{Re}[(Z-Z_r)e^{-\mathrm{i}\psi}]}{S_0(1+\beta\Delta T)}.
$$

Forward voltage gives $\Delta T=(V_F-V_{F0})/(N_c\gamma_V)$. The signed projection rejects exactly quadrature drift and exposes reversed polarity. The mean of the six directed adjacent ratios gives the coupling index. A joint search over the adjacent-pair curves fits extent and a shared liner scale. Ratios from distant pairs still contribute to polarity checks. At the dark floor the estimator reports extent 0 as a sentinel for absent optical return. A dark reading alone cannot resolve an edge position.

## Timing and verdict precedence

A daylight scan requires at least 30 s of settling, average wind below 5 m/s, incidence up to 65°, irradiance of at least 50 W/m² and reference change up to 2%. The file supplies wind and reference stability over the measurement window. Each strip gets 0.8 s to settle and 1.6 s to integrate. Overlapping scan requests are rejected. Full fusion requires three accepted scans spanning at least 15° and three adequately illuminated scans (DNI / plane irradiance at least 0.25) also spanning 15°.

The night session requires irradiance below 1 W/m², at least one hour since sunset, and forward-voltage change no greater than 0.1%. Each of four emitters occupies a 16 s slot with ramp-up, integration, ramp-down and idle. The timeline emits a 90 s alarm when night evidence cannot verify deployment. The day and night records represent distinct sessions on separate clocks. The deadline models a single night verification request. A mechanical deployment transient and a repeated alarm/redeployment loop are outside this implementation.

| Priority | Code | Trigger and interpretation |
| --- | --- | --- |
| 1 | HOLD | Isolation unconfirmed. The schedule contains no active receive or emit windows. |
| 2 | FAULT | Any signed pair ratio below −0.08. Check receiver polarity. |
| 3 | A | Coupling below 0.50 or edge shortfall greater than 0.14 m. Suppress aperture fitting. |
| 4 | HOLD | Required night evidence or daylight angular support missing. |
| 5 | B, F, HOLD | Persistent positive signal. A good roof fit gives B and a good wall fit gives F with a side. A poor residual gives unresolved F. An ambiguous family gives HOLD. |
| 6 | C, D | Persistent corrected deficit gives C. Retracted gain below 0.82 gives D. |
| 7 | E | Weak night coupling below 0.90 at full extent with no preceding local fault. Wetting or delamination is one physical interpretation of reduced return. |
| 8 | F, G | Median section factor outside [0.82, 1.18] gives a common-shift F. Otherwise the result is G. |

A uniform lift and an untracked common reference error can produce the same factor. The code reports that ambiguity. Each experiment yields one highest-priority verdict. Secondary clues such as low-gain strips are retained in the summary. When a candidate is ambiguous or poorly fitting, its numbers are diagnostic hypotheses only.

## Scope

All commissioning curves, efficiencies, noise levels and optical scales are synthetic. The simulator represents the four switching modes in software. A circuit transient model, measured ADC transfer function, field sky reconstruction, multiple aperture recovery, multidirectional scattering from the liner and structural impact response would require additional models and data. Simulated dimensions or operating values describe only this numerical experiment.
