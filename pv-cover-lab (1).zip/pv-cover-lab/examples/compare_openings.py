"""Render the two experiments in the README. Run after installing the plot extra."""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap

from pvcover import load_scenario, load_sky, run
from pvcover.config import N_STRIPS


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("runs/opening-comparison.png"))
    args = parser.parse_args()
    sky = load_sky()
    results = [run(load_scenario(n), sky, 42) for n in ("cover-hole", "lower-slot")]
    cmap = LinearSegmentedColormap.from_list("irradiance", ["#f1f3ed", "#a5d6bf", "#36998b", "#07505c"])
    fig = plt.figure(figsize=(11.8, 5.7), facecolor="white")
    grid = fig.add_gridspec(1, 3, left=.078, right=.94, top=.72, bottom=.18,
                            width_ratios=[1, 1, .035], wspace=.23)
    fig.text(.078, .925, "One position, two sunlight signatures", fontsize=24,
             color="#133b43", weight="bold")
    fig.text(.08, .852, "A circular cover hole and a lower-skirt slot centred at x = 1.737 m"
             " on a synthetic four-module row.", fontsize=12, color="#465c60")
    vmax = max(e.reduced.excess.max() for e in results)
    for i, (res, title) in enumerate(zip(results, ["Cover plane", "Lower skirt"])):
        ax = fig.add_subplot(grid[0, i])
        # Preserve elapsed time even where acquisition gates skipped a scan.
        matrix = np.full((N_STRIPS, len(sky)), np.nan)
        for scan, values in zip(res.day.scans, res.reduced.excess):
            matrix[:, sky.index(scan)] = values
        cmap.set_bad("#c2c7cd")
        im = ax.imshow(matrix, origin="lower", aspect="auto", cmap=cmap, vmin=0, vmax=vmax,
                       interpolation="nearest", extent=(-2.5, 77.5, .5, N_STRIPS + .5))
        ax.set_title(title, loc="left", fontweight="bold", color="#133b43", fontsize=14, pad=9)
        ax.set_yticks([1, 3, 5, 7, 9, 12])
        ax.set_xticks([0, 15, 30, 45, 60, 75])
        ax.set_xlabel("Elapsed time (min)")
        if i == 0:
            ax.set_ylabel("Substring along row")
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.tick_params(length=0, pad=5, colors="#43595b")
    cb = fig.colorbar(im, cax=fig.add_subplot(grid[0, 2]))
    cb.set_label("Positive excess index")
    cb.outline.set_visible(False)
    fig.text(.08, .045, "Grey columns mark rejected scans. Both panels use the same colour scale."
             " Negative excess is clipped to zero for display.", fontsize=10, color="#465c60")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.out, dpi=155, metadata={"Software": "PV Cover Lab"})
    plt.close(fig)


if __name__ == "__main__":
    main()
