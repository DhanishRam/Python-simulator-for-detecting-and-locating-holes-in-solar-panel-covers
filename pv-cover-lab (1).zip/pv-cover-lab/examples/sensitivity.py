"""Sweep aperture size, sky and measured gap at independently drawn off-grid positions."""
import argparse
from dataclasses import replace
from pathlib import Path

import numpy as np

from pvcover import Opening, Scenario, load_sky, run
from pvcover.config import LENGTH
from pvcover.output import new_bundle, write_rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trials", type=int, default=6, help="replicates per combination")
    parser.add_argument("--seed", type=int, default=730)
    parser.add_argument("--out", type=Path, default=Path("runs/sensitivity"))
    args = parser.parse_args()
    if args.trials < 1 or args.seed < 0:
        parser.error("use a positive trial count and a nonnegative seed")
    # Reuse positions and readout seeds across conditions for a paired comparison.
    rng = np.random.default_rng(args.seed)
    positions = rng.uniform(0.15, LENGTH - 0.15, args.trials)
    sky = load_sky()
    rows = []
    with new_bundle(args.out) as out:
        for regime, beam, diffuse in [("clear", 1, 1), ("hazy", .30, 3), ("overcast", 0, 3)]:
            scans = tuple(replace(s, dni_w_m2=s.dni_w_m2*beam, diffuse_w_m2=s.diffuse_w_m2*diffuse)
                          for s in sky)
            for gap in (0.22, 0.32, 0.39):
                for radius in (0.012, 0.025, 0.050):
                    for i, x in enumerate(positions):
                        area = float(np.pi * radius**2)
                        case = Scenario(name="sensitivity", gap_m=gap, opening=Opening("cover", float(x), area))
                        result = run(case, scans, args.seed + i)
                        fit = result.fit if result.verdict.code == "B" else None
                        rows.append({"sky": regime, "gap_m": gap, "radius_m": radius, "x_true_m": x,
                                     "area_true_m2": area, "seed": args.seed + i, "verdict": result.verdict.code,
                                     "x_error_m": fit.candidate.x_m - x if fit else None,
                                     "area_error_pct": 100*(fit.area_m2/area-1) if fit else None})
        write_rows(out / "sensitivity.csv", list(rows[0]), rows)
    print(f"Wrote {len(rows)} trials to {args.out}")


if __name__ == "__main__":
    main()
