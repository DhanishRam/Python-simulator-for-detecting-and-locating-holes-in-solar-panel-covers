import unittest
from dataclasses import replace

import numpy as np

from pvcover import Opening, Scenario, load_scenario, load_sky, run
from pvcover.config import LENGTH, N_STRIPS, STRIP_AREA
from pvcover.day import baseline
from pvcover.inverse import fit_opening, kernel_bank
from pvcover.night import demodulate, oscillator, projection
from pvcover.optics import K_SCALE, aperture_signal, diffuse_directions, frame, hits


class OpticsTests(unittest.TestCase):
    def setUp(self):
        self.sky = load_sky()
        self.accepted = tuple(s for s in self.sky if not s.rejection())

    def test_downward_rays_conserve_only_captured_power(self):
        start = np.array([[.1, .5, .3], [.1, .5, .3], [4.75, .5, .3], [.1, .5, .3]])
        rays = np.array([[0, 0, -1], [0, 0, 1], [1, 0, -1], [0, 0, 0]])
        portions = hits(start, rays)
        self.assertAlmostEqual(portions[0], .25)
        self.assertAlmostEqual(sum(portions), .25)

    def test_hemisphere_orientations(self):
        for family in ("cover", "lower_skirt", "upper_skirt", "end_flap"):
            directions = diffuse_directions(family, 128)
            np.testing.assert_allclose(np.linalg.norm(directions, axis=1), 1)
            self.assertTrue(np.all(directions @ frame(family)[0] > 0))

    def test_normal_cover_flux_and_dark_skirt(self):
        s = replace(self.sky[0], theta_deg=0, diffuse_w_m2=0)
        cover = Opening("cover", 1.0, .01)
        signal = aperture_signal(cover, .32, [s])
        self.assertAlmostEqual(signal.sum(), .01*K_SCALE/STRIP_AREA)
        slot = Opening("lower_skirt", 1.0, .01, .15)
        self.assertEqual(aperture_signal(slot, .32, [s]).sum(), 0)

    def test_one_pitch_of_parallax_moves_the_signal_one_strip(self):
        a = replace(self.sky[0], theta_deg=0, phi_deg=0, diffuse_w_m2=0)
        b = replace(a, theta_deg=45)
        signals = aperture_signal(Opening("cover", 1.0, .001), .4, [a, b])
        self.assertEqual(signals[1].argmax(), signals[0].argmax() + 1)
        np.testing.assert_allclose(signals.sum(axis=1), .001*K_SCALE/STRIP_AREA)

    def test_baseline_varies_with_position_and_measured_gap(self):
        a = baseline(self.accepted, .24)
        self.assertGreater(a[0, -1], a[0, 6])
        self.assertTrue(np.all(a > baseline(self.accepted, .38)))

    def test_known_area_least_squares_and_zero_energy(self):
        specs, bank = kernel_bank(self.accepted, .32)
        idx = next(i for i, c in enumerate(specs) if c.family == "cover" and abs(c.x_m-2.04) < 1e-5)
        record = .0083*bank[idx]
        fit = fit_opening(record, self.accepted, .32)
        self.assertEqual(fit.candidate, specs[idx])
        self.assertAlmostEqual(fit.area_m2, .0083)
        self.assertLess(fit.residual, 1e-10)
        self.assertIsNone(fit_opening(np.zeros_like(record), self.accepted, .32))
        self.assertEqual(fit_opening(-record, self.accepted, .32).area_m2, 0)

    def test_quadrature_rejection_and_signed_polarity(self):
        phi = -.46
        zr = .7 + .84j
        for signed in [-1, .02, 1]:
            signal = (signed + .41j)*np.exp(1j*phi) + zr
            measured = demodulate(4.2 + (signal*oscillator()).real)
            self.assertAlmostEqual(projection(measured, zr, phi), signed)
        with self.assertRaises(ValueError):
            demodulate([0, 1])

    def test_gap_and_temperature_correct_at_commissioned_condition(self):
        for gap, temp in ((.20, -5), (.32, 25), (.40, 65)):
            e = run(Scenario(gap_m=gap, cell_temp_c=temp, relative_noise=0), self.sky)
            self.assertAlmostEqual(e.night.index, 1, places=10)
            self.assertAlmostEqual(e.night.extent_m, LENGTH)
            self.assertEqual(e.verdict.code, "G")

    def test_gain_and_median_remove_uniform_reference_and_soiling(self):
        e = run(Scenario(reference_scale=.9, soiled_strip=6, relative_noise=0), self.sky)
        np.testing.assert_allclose(e.reduced.gamma, 1/.9)
        np.testing.assert_allclose(e.reduced.excess, 0, atol=1e-15)
        self.assertEqual(e.summary()["day"]["low_gain_strips"], [6])

    def test_bank_rebuilds_for_different_gap(self):
        _, small = kernel_bank(self.accepted, .2)
        _, large = kernel_bank(self.accepted, .4)
        self.assertEqual(small.shape[-1], N_STRIPS)
        self.assertFalse(np.allclose(small[10], large[10]))

    def test_full_coverage_weak_liner_separable_from_partial(self):
        for name, extent in (("wet-liner", LENGTH), ("partial", .73*LENGTH)):
            e = run(replace(load_scenario(name), relative_noise=0), self.sky)
            self.assertLess(abs(e.night.extent_m - extent), .04)
