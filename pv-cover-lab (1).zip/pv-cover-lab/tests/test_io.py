import csv
import io
import json
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import asdict
from pathlib import Path

from pvcover import Opening, Scenario, load_scenario, load_sky, run
from pvcover.cli import main
from pvcover.config import DATA, scenario_from_dict
from pvcover.output import new_bundle


class InputsAndCLI(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def cli(self, *args):
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = main(list(map(str, args)))
        return code, out.getvalue(), err.getvalue()

    def test_strict_scenarios(self):
        for bad in ([2], {"unknown": 2}, {"opening": []}, {"gap_m": True}, {"gap_m": float("nan")},
                    {"soiled_strip": 2.5}, {"name": ""}, {"isolated": 0}, {"gap_m": .1},
                    {"opening": {"family": "ceiling", "x_m": 1, "area_m2": .01}},
                    {"opening": {"family": "cover", "x_m": 1, "area_m2": .01, "height_m": .1}},
                    {"opening": {"family": "lower_skirt", "x_m": 1, "area_m2": .01, "height_m": .001}},
                    {"opening": {"family": "end_flap", "x_m": 2, "area_m2": .01, "height_m": .16}},
                    {"opening": {"family": "cover", "x_m": .001, "area_m2": .01}}):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                scenario_from_dict(bad)
        with self.assertRaises(ValueError):
            Scenario(opening=3)
        with self.assertRaises(ValueError):
            load_scenario("missing-name")
        s = Scenario(opening=Opening("cover", 2, .01))
        self.assertEqual(scenario_from_dict(asdict(s)), s)

    def test_sky_validation(self):
        path = self.root / "sky.csv"
        lines = DATA.joinpath("sky.csv").read_text(encoding="utf-8").splitlines()
        for content in (["wrong,header"], lines[:1], [*lines[:2], lines[1]],
                        [lines[0], lines[1].replace("720", "nan")],
                        [*lines[:1], lines[1]+",extra"]):
            path.write_text("\n".join(content), encoding="utf-8")
            with self.assertRaises(ValueError):
                load_sky(path)
        with self.assertRaises(ValueError):
            run(Scenario(), [])
        with self.assertRaises(ValueError):
            run(Scenario(), load_sky(), -1)

    def test_cli_resources_and_replay(self):
        self.assertIn("lower-slot", self.cli("list")[1])
        out = self.root / "run"
        self.assertEqual(self.cli("run", "--out", out)[0], 0)
        names = {f.name for f in out.iterdir()}
        self.assertEqual(names, {"summary.json", "scenario.json", "day.csv", "night.csv", "timeline.csv",
                                 "scan_log.csv", "sky.csv"})
        with (out/"day.csv").open() as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 14*12)
        self.assertTrue(all(float(r["reference_a"]) > 0 for r in rows))
        target = self.root / "replay"
        self.assertEqual(self.cli("run", "--scenario", out/"scenario.json", "--sky", out/"sky.csv",
                                  "--seed", "42", "--out", target)[0], 0)
        for filename in names:
            self.assertEqual((out/filename).read_bytes(), (target/filename).read_bytes())
        self.assertEqual(self.cli("run", "--out", out)[0], 2)

    def test_cli_benchmark_and_errors(self):
        out = self.root / "bench"
        self.assertEqual(self.cli("benchmark", "--trials", "1", "--out", out)[0], 0)
        with (out/"trials.csv").open() as handle:
            self.assertEqual(len(list(csv.DictReader(handle))), 15)
        config = json.loads((out/"settings.json").read_text())
        self.assertEqual(config["start_seed"], 42)
        bad = self.root / "bad"
        self.assertEqual(self.cli("run", "--preset", "typo", "--out", bad)[0], 2)
        self.assertFalse(bad.exists())
        self.assertEqual(self.cli("run", "--scenario", self.root/"missing", "--out", bad)[0], 2)

    def test_failed_write_does_not_publish_partial_bundle(self):
        out = self.root / "bundle"
        with self.assertRaises(RuntimeError), new_bundle(out) as staging:
            (staging/"partial.csv").touch()
            raise RuntimeError("simulated interrupted write")
        self.assertFalse(out.exists())

    def test_unavailable_measurements_round_trip_as_null(self):
        summary = run(load_scenario("interlock-open"), load_sky()).summary()
        parsed = json.loads(json.dumps(summary, allow_nan=False))
        self.assertIsNone(parsed["night"]["coupling_index"])
        self.assertIsNone(parsed["day"]["median_gamma"])
