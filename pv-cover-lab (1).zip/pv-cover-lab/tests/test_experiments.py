import unittest
from dataclasses import replace

import numpy as np

from pvcover import Scenario, load_scenario, load_sky, run
from pvcover.acquisition import timeline
from pvcover.inverse import Candidate, Fit
from pvcover.simulation import decide
from pvcover.study import EXPECTED, ablations, benchmark


class Experiments(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sky = load_sky()

    def test_all_default_verdicts(self):
        for name, code in EXPECTED.items():
            with self.subTest(name=name):
                e = run(load_scenario(name), self.sky)
                self.assertEqual(e.verdict.code, code)
                if name in {"lower-slot", "upper-slot", "end-flap"}:
                    self.assertEqual(e.verdict.label, e.scenario.opening.family)

    def test_known_off_grid_opening_recovered_from_currents(self):
        e = run(load_scenario("cover-hole"), self.sky)
        self.assertLess(abs(e.fit.candidate.x_m - e.scenario.opening.x_m), .04)
        self.assertLess(abs(e.fit.area_m2/e.scenario.opening.area_m2-1), .10)
        self.assertGreater(e.fit.margin, .2)
        self.assertEqual(len(e.night.pairs), 12)
        self.assertEqual(len(e.day.scans), 14)

    def test_multiple_seeds_and_independent_day_night_streams(self):
        s = load_scenario("cover-hole")
        a, b = run(s, self.sky, 9), run(s, self.sky, 9)
        np.testing.assert_array_equal(a.day.current_a, b.day.current_a)
        self.assertEqual(a.summary(), b.summary())
        self.assertFalse(np.array_equal(a.day.current_a, run(s, self.sky, 10).day.current_a))
        self.assertEqual(a.night, run(s, self.sky[:1], 9).night)

    def test_overcast_narrow_span_and_sparse_support(self):
        for sky, why in ((tuple(replace(s, dni_w_m2=0) for s in self.sky), "weak_direct_light"),
                         (tuple(replace(s, theta_deg=35) for s in self.sky), "narrow_angle_span"),
                         (self.sky[:2], "too_few_scans"),
                         (tuple(replace(s, wind_m_s=8) for s in self.sky), "too_few_scans")):
            e = run(load_scenario("cover-hole"), sky)
            self.assertEqual(e.day_issue, why)
            self.assertEqual(e.verdict.code, "HOLD")
            self.assertIsNone(e.fit)

    def test_angle_support_must_include_directly_illuminated_scans(self):
        scans = tuple(replace(s, dni_w_m2=0) if s.theta_deg > 30 else replace(s, theta_deg=22)
                      for s in self.sky)
        e = run(load_scenario("cover-hole"), scans)
        self.assertEqual(e.day_issue, "narrow_direct_angle_span")
        self.assertEqual(e.verdict.code, "HOLD")

    def test_primary_verdict_retains_secondary_gain_evidence(self):
        case = replace(load_scenario("lower-slot"), soiled_strip=10)
        e = run(case, self.sky)
        self.assertEqual(e.verdict.label, "lower_skirt")
        self.assertEqual(e.summary()["day"]["low_gain_strips"], [10])

    def test_interlock_and_partial_never_publish_opening_estimates(self):
        blocked = run(load_scenario("interlock-open"), self.sky)
        self.assertEqual(blocked.day.current_a.shape, (0, 12))
        self.assertIsNone(blocked.night)
        self.assertTrue(all("emit" not in ev.module_modes and "receive" not in ev.module_modes
                            for ev in timeline(blocked)))
        for name in ("partial", "retracted", "wiring-fault", "unstable-night"):
            self.assertIsNone(run(load_scenario(name), self.sky).fit)

    def test_night_admission(self):
        for key, value, reason in (("night_irradiance_w_m2", 1, "night_too_bright"),
                                   ("hours_after_sunset", .9, "too_early"),
                                   ("voltage_change_fraction", .0011, "forward_voltage_unstable")):
            e = run(replace(Scenario(), **{key: value}), self.sky)
            self.assertIsNone(e.night)
            self.assertEqual(e.night_issue, reason)
            self.assertEqual(e.verdict.code, "HOLD")

    def test_each_sky_gate_and_boundary(self):
        first = self.sky[0]
        for key, value, reason in (("settled_s", 29.9, "unsettled"), ("wind_m_s", 5, "wind"),
                                   ("theta_deg", 65.01, "incidence"), ("ref_change", .021, "reference_unstable")):
            self.assertEqual(replace(first, **{key: value}).rejection(), reason)
        self.assertEqual(replace(first, dni_w_m2=0, diffuse_w_m2=49).rejection(), "dim")
        self.assertFalse(replace(first, theta_deg=65, settled_s=30, ref_change=.02,
                                 wind_m_s=4.99, dni_w_m2=0, diffuse_w_m2=50).rejection())

    def test_substring_selection_and_time_accounting(self):
        e = run(Scenario(), self.sky[:1])
        events = list(timeline(e))
        selects = [ev for ev in events if ev.action == "select_strip"]
        self.assertEqual([ev.strip for ev in selects], list(range(1, 13)))
        self.assertTrue(all(ev.module_modes.split("|").count("strip_receive") == 1 for ev in selects))
        self.assertEqual(events[-1].time_s, 28.8)
        self.assertEqual([ev.time_s for ev in events if ev.action == "integrate_10s"], [2, 18, 34, 50])
        self.assertFalse(any(ev.action.endswith("alarm") for ev in events))
        fail = list(timeline(run(load_scenario("partial"), self.sky[:1])))
        self.assertIn((90, "deployment_unverified_alarm"), [(ev.time_s, ev.action) for ev in fail])

    def test_overlapping_scans_are_skipped(self):
        scans = tuple(replace(self.sky[0], time_s=t) for t in [0, 5, 28.8])
        e = run(Scenario(), scans)
        self.assertEqual([why for _, why in e.admissions], ["", "acquisition_busy", ""])

    def test_unexplained_or_ambiguous_leakage(self):
        night = run(Scenario(), self.sky).night
        c = Candidate("cover", 2, .32)
        for fit, label in ((Fit(c, .01, .7, "upper_skirt", .9), "unresolved_edge_or_leakage"),
                           (Fit(c, .01, .1, "upper_skirt", .11), "ambiguous_aperture"),
                           (None, "insufficient_signal")):
            self.assertEqual(decide(night, False, "", True, False, False, 1, fit).label, label)

    def test_baseline_ablations_share_observations(self):
        raw, local, coarse = ablations(run(load_scenario("reference-drift"), self.sky))
        self.assertTrue(raw)
        self.assertFalse(local or coarse)
        raw, local, coarse = ablations(run(load_scenario("lower-slot"), self.sky))
        self.assertTrue(raw and local)
        self.assertFalse(coarse)

    def test_benchmark_keeps_missing_results_and_denominators(self):
        results, confusion = benchmark(self.sky, 2, 42)
        self.assertEqual(len(results), len(EXPECTED)*2)
        self.assertEqual(sum(r["count"] for r in confusion), len(results))
        inactive = next(r for r in results if r["scenario"] == "interlock-open")
        self.assertIsNone(inactive["module_fit_hole"])
        self.assertIsNone(inactive["x_error_m"])
        with self.assertRaises(ValueError):
            benchmark(self.sky, 0, 1)
